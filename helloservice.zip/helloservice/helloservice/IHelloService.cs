﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloService
{
    [ServiceContract(Namespace = "http://PragimTech.com/ServiceVersion1")]
    public interface IHelloService
    {
        [OperationContract]
        string GetMessage(string name);
    }
}