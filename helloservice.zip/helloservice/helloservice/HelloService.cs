﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloService
{
    public class HelloService : IHelloService
    {

            public string GetMessage(string name)
            { if (name == "Ali ")
            {
                return "Status: Found  " + "Name: Ali Helal  " + "Age: 57 ";
            }
            if (name == "Amany ")
            {
                return "Status: Found  "+"Name: Amany Akram  "  + "Age: 23  ";
            }
            if (name == "Noha ")
            {
                return "Status: Found  "+"Name: Noha Yazed  "  + "Age: 22 ";
            }
            if (name == "Arwa")
            {
                return "Status: Found  "+ "Name: Arwa Tarek  "  + "Age: 21";
            }

            else
            {
                return "Status: Not Found";
            }
            }
        }
    }
